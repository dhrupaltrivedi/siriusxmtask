package com.vehicle.controller;

import java.util.UUID;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.vehicle.exceptions.InvalidValueFoundException;
import com.vehicle.model.VehicleModel;


@RestController
@RequestMapping(path = "/api")
public class VehicleController {
	
	@PostMapping(path = "/vehicles/vehicle" , consumes = "application/json", produces = "application/json")
	public ResponseEntity<String> createVehicle(@Valid @RequestBody VehicleModel model, WebRequest webRequest) {
		
		System.out.println(model);
		String vehicleId = UUID.randomUUID().toString();
		ResponseEntity<String> resp = null; 
		//resp = new ResponseEntity<String>(vehicleId,HttpStatus.OK);
		if(model.getTransmissionType().equalsIgnoreCase("AUTO") || model.getTransmissionType().equalsIgnoreCase("MANUAL")) {
			resp = new ResponseEntity<String>(vehicleId,HttpStatus.OK);
		} else {
			throw new InvalidValueFoundException("Invalid Transmission Type : " + model.getTransmissionType());
		}
		
		return resp;
	}
}