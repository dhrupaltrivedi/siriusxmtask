package com.vehicle.model;

import javax.validation.constraints.NotEmpty;

public class VehicleModel {
	@NotEmpty(message = "Please provide vin.")
	private String vin;
	@NotEmpty(message = "Please provide year.")
	private String year;
	@NotEmpty(message = "Please provide make.")
	private String make;
	@NotEmpty(message = "Please provide model.")
	private String model;
	@NotEmpty(message = "Please provide transmission type.")
	private String transmissionType;
	
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getTransmissionType() {
		return transmissionType;
	}
	public void setTransmissionType(String transmissionType) {
		this.transmissionType = transmissionType;
	}
	@Override
	public String toString() {
		return "VehicleModel [vin=" + vin + ", year=" + year + ", make=" + make + ", model=" + model
				+ ", transmissionType=" + transmissionType + "]";
	}
	
	
}
