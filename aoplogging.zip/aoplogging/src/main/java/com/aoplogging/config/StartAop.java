package com.aoplogging.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.aoplogging.service.DBServiceA;
import com.aoplogging.service.HttpServiceB;

public class StartAop {
	public static void main(String[] args) {
		 
		ApplicationContext context1 = new ClassPathXmlApplicationContext
                ("applicationContext.xml");
		DBServiceA dbService = (DBServiceA) context1.getBean("DBServiceA");
		
		dbService.getData(101);
		
		
		ApplicationContext context2 = new ClassPathXmlApplicationContext
                ("applicationContext.xml");
		HttpServiceB httpService = (HttpServiceB) context2.getBean("HttpServiceB");
		
		httpService.sendMessage("request");
		
    }
}
