package com.aoplogging.service;

public class HttpServiceB {
	public String sendMessage(String message) {
        //log.debug(message);
        
        /*
         assume that some message sends via rest client and gets "httpResponse"
        */
        String httpResponse = "httpResponse";
        
        //log.debug(httpResponse);
        return httpResponse;

    }
}
