package com.aoplogging.service;

public class DBServiceA {
	public String getData(int id) {
		//log.debug(id);

        /*
         assume that some data has been retrieved from DB by id
        */
        String resultData = "resultData";
        
        //log.debug(resultData);
        return resultData;
    }
}
