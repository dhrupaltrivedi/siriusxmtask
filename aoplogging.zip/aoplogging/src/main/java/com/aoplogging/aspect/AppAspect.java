package com.aoplogging.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class AppAspect {

	@Before("execution(* com.aoplogging.service.DBServiceA.getData(..)) && args(id,..)")
	public void logBeforeDBService(JoinPoint joinPoint, int id) {
		System.out.println("DBSerivce Before | method : " + joinPoint.getSignature().getName() +"  parameter :"+ id);
	}
	
	@AfterReturning(pointcut="execution(* com.aoplogging.service.DBServiceA.getData(..))" , returning="retVal")
	public void logAfterDBService(JoinPoint joinPoint, Object retVal) {
		System.out.println("DBSerivce After Return | method : " + joinPoint.getSignature().getName()+"  return type :"+retVal);
	}
	
	@Before("execution(* com.aoplogging.service.HttpServiceB.sendMessage(..)) && args(message,..)")
	public void logBeforeHttpService(JoinPoint joinPoint, String message) {
		System.out.println("HttpService Before | method : " + joinPoint.getSignature().getName() +"  parameter :"+ message);
	}
	
	@AfterReturning(pointcut="execution(* com.aoplogging.service.HttpServiceB.sendMessage(..))" , returning="retVal")
	public void logAfterHttpService(JoinPoint joinPoint, Object retVal) {
		System.out.println("HttpService After Return | method : " + joinPoint.getSignature().getName()+"  return type :"+retVal);
	}
}
